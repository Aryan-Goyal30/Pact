import "dotenv/config";
import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";

const adapter = new PrismaBetterSqlite3({
  url: process.env.DATABASE_URL ?? "file:./dev.db",
});

const prisma = new PrismaClient({ adapter });

async function main() {
  await prisma.merchant.deleteMany();
  await prisma.catalogItem.deleteMany();

  await prisma.merchant.create({
    data: {
      name: "PACT Demo Electronics",
      description: "B2B electronics supplier offering laptops, monitors, and accessories for bulk office orders.",
      deliveryPolicy: "Standard delivery within listed lead time; bulk orders may be split into batches.",
      returnPolicy: "7-day return window for unopened units.",
      negotiationEnabled: true,
    },
  });

  await prisma.catalogItem.createMany({
    data: [
      {
        sku: "LAPTOP-14-I5",
        name: "14-inch Business Laptop (i5, 16GB RAM)",
        description: "Mid-range business laptop suitable for office use.",
        listedPrice: 48000,
        minPrice: 44000,
        // Catalog/preset recalibration: 100 -> 10. Price/delivery economics
        // unchanged — only stock is lowered, deliberately repurposing this
        // item as the scarce-inventory / partial-fulfillment / premium
        // product (its own price band already made anything above ~10
        // units unpayable under the real Razorpay ~₹5,00,000 transaction
        // ceiling; this makes that ceiling and this item's stock agree,
        // rather than papering over the mismatch in negotiation code).
        availableQty: 10,
        standardDeliveryDays: 5,
        maxDeliveryDays: 12,
        negotiationEnabled: true,
      },
      {
        sku: "MONITOR-24-FHD",
        name: "24-inch Full HD Monitor",
        description: "Standard office monitor, 1920x1080.",
        listedPrice: 9500,
        minPrice: 8200,
        availableQty: 250,
        standardDeliveryDays: 4,
        maxDeliveryDays: 10,
        negotiationEnabled: true,
      },
      {
        sku: "KEYBOARD-WIRELESS",
        name: "Wireless Keyboard and Mouse Combo",
        description: "Standard wireless keyboard and mouse set.",
        listedPrice: 1400,
        minPrice: 1150,
        availableQty: 500,
        standardDeliveryDays: 3,
        maxDeliveryDays: 7,
        // Catalog/preset recalibration: false -> true. A pure demo/business
        // data decision (this SKU's cheap unit price + high stock are what
        // make it the only current product that can demonstrate abundant
        // inventory / the large-order quantity threshold while staying
        // under the real Razorpay transaction ceiling) — no negotiation
        // code was changed to special-case this item; it goes through
        // exactly the same rule engine every other negotiable product does.
        negotiationEnabled: true,
      },
    ],
  });
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
