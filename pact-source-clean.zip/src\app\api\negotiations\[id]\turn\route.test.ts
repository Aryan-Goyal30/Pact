// Integration tests for POST /api/negotiations/:id/turn, focused on the
// hardening added after the Agreement + AuditLog milestone: a repeated
// POST against an already-AGREED session must be a safe, idempotent
// replay (no new orchestrator turn, no LLM call, no duplicate Agreement
// or AuditLog row) rather than the plain 409 it used to return. Exercises
// the real route handler end to end against the real dev database, the
// same "real Prisma/SQLite" exception to the no-DB-tests convention that
// agreementRepository.test.ts documents.

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { prisma } from "@/lib/prisma";
import { AUDIT_EVENT_AGREEMENT_CREATED } from "@/lib/negotiation/agreementRepository";
import { createNegotiationSession } from "@/lib/negotiation/negotiationSessionRepository";
import { getLlmProvider } from "@/lib/llm/provider";
import { POST } from "./route";
import type { BuyerConstraints } from "@/lib/rules/buyerRules";
import type { NegotiationTurnResponse } from "@/types/negotiation";

vi.mock("@/lib/llm/provider", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/llm/provider")>();
  return { ...actual, getLlmProvider: vi.fn() };
});

const mockedGetLlmProvider = vi.mocked(getLlmProvider);
const generateAgentMessage = vi.fn().mockResolvedValue("mocked agent message");

const LAPTOP_SKU = "LAPTOP-14-I5";
let sessionIdsToClean: string[] = [];

beforeEach(() => {
  sessionIdsToClean = [];
  generateAgentMessage.mockClear();
  mockedGetLlmProvider.mockReturnValue({ generateAgentMessage });
});

afterEach(async () => {
  for (const id of sessionIdsToClean) {
    await prisma.auditLog.deleteMany({ where: { sessionId: id } });
    await prisma.agreement.deleteMany({ where: { sessionId: id } });
    await prisma.negotiationMessage.deleteMany({ where: { sessionId: id } });
    await prisma.negotiationSession.deleteMany({ where: { id } });
  }
});

async function createTestSession(buyerConstraints: BuyerConstraints, maxRounds = 4): Promise<string> {
  const session = await createNegotiationSession(LAPTOP_SKU, buyerConstraints, maxRounds);
  sessionIdsToClean.push(session.id);
  return session.id;
}

async function callTurn(id: string): Promise<{ status: number; body: NegotiationTurnResponse }> {
  const response = await POST(new Request("http://localhost/api/negotiations/x/turn", { method: "POST" }), {
    params: Promise.resolve({ id }),
  });
  return { status: response.status, body: (await response.json()) as NegotiationTurnResponse };
}

// Buyer ceiling of 48000 meets the merchant's listed price, so this
// reaches AGREED in exactly two turns: turn 1 the buyer opens near its
// target and the merchant counters at the anchored midpoint (47160 —
// catalog/preset recalibration: LAPTOP-14-I5's availableQty dropped
// 100 -> 10, so requesting exactly 10 no longer leaves the buyer any
// fulfillability leverage — ratio (avail-qty)/avail is now 0, not 0.9 —
// and the merchant holds a firmer counter than the pre-recalibration
// 46800); turn 2 the buyer accepts since 47160 is within its 48000
// ceiling. This is the same deterministic sequence
// agreementRepository.test.ts's "I" test relies on.
const AGREEING_CONSTRAINTS: BuyerConstraints = {
  sku: LAPTOP_SKU,
  quantity: 10,
  maxUnitPrice: 48000,
  deliveryDeadlineDays: 5,
};

describe("POST /api/negotiations/:id/turn — replay after AGREED", () => {
  it("A: the first turn that reaches AGREED creates exactly one Agreement and one AuditLog", async () => {
    const sessionId = await createTestSession(AGREEING_CONSTRAINTS);

    await callTurn(sessionId); // turn 1: counter_offer
    const closing = await callTurn(sessionId); // turn 2: AGREED

    expect(closing.status).toBe(200);
    expect(closing.body.status).toBe("AGREED");
    expect(closing.body.agreement).not.toBeNull();
    expect(closing.body.agreement).toMatchObject({
      sku: LAPTOP_SKU,
      quantity: 10,
      unitPrice: 47160,
      deliveryDays: 5,
      totalAmount: 471600,
      status: "pending_payment",
    });

    expect(await prisma.agreement.count({ where: { sessionId } })).toBe(1);
    expect(
      await prisma.auditLog.count({ where: { sessionId, eventType: AUDIT_EVENT_AGREEMENT_CREATED } }),
    ).toBe(1);
  });

  // Leverage-visualization milestone: every turn response carries a live,
  // server-computed leverage score (never from the LLM) — this proves the
  // real API data path, not just the pure computeLeverage() unit tests.
  it("every turn response includes a valid 0-100 leverage score, and the AGREED replay recomputes it consistently", async () => {
    const sessionId = await createTestSession(AGREEING_CONSTRAINTS);

    const first = await callTurn(sessionId);
    expect(first.body.leverage.buyer + first.body.leverage.merchant).toBe(100);
    expect(first.body.leverage.buyer).toBeGreaterThanOrEqual(0);
    expect(first.body.leverage.buyer).toBeLessThanOrEqual(100);

    const closing = await callTurn(sessionId); // AGREED
    expect(closing.body.leverage.buyer + closing.body.leverage.merchant).toBe(100);

    const replay = await callTurn(sessionId);
    expect(replay.body.leverage).toEqual(closing.body.leverage);
  });

  it("B, C, D, E: repeating the POST after AGREED replays the same Agreement without a new turn, LLM call, Agreement, or AuditLog", async () => {
    const sessionId = await createTestSession(AGREEING_CONSTRAINTS);

    await callTurn(sessionId); // turn 1
    const closing = await callTurn(sessionId); // turn 2: AGREED
    const callsAfterClosing = generateAgentMessage.mock.calls.length;

    const replay = await callTurn(sessionId);

    // B: same Agreement.
    expect(replay.status).toBe(200);
    expect(replay.body.status).toBe("AGREED");
    expect(replay.body.agreement).toEqual(closing.body.agreement);

    // C, D: no duplicate rows.
    expect(await prisma.agreement.count({ where: { sessionId } })).toBe(1);
    expect(
      await prisma.auditLog.count({ where: { sessionId, eventType: AUDIT_EVENT_AGREEMENT_CREATED } }),
    ).toBe(1);

    // E: the LLM was not invoked again for the replay.
    expect(generateAgentMessage.mock.calls.length).toBe(callsAfterClosing);

    // Replaying again (a third time) is equally safe.
    const secondReplay = await callTurn(sessionId);
    expect(secondReplay.status).toBe(200);
    expect(secondReplay.body.agreement).toEqual(closing.body.agreement);
    expect(await prisma.agreement.count({ where: { sessionId } })).toBe(1);
    expect(generateAgentMessage.mock.calls.length).toBe(callsAfterClosing);
  });

  it("F: the replay response contains no minPrice or private reservation value", async () => {
    const sessionId = await createTestSession(AGREEING_CONSTRAINTS);

    await callTurn(sessionId);
    await callTurn(sessionId); // AGREED
    const replay = await callTurn(sessionId);

    const serialized = JSON.stringify(replay.body);
    expect(serialized).not.toContain("minPrice");
    expect(serialized).not.toContain("44000"); // the seeded LAPTOP-14-I5 private floor
  });

  // PACT V2 Milestone 4 regression: the DB-backed path (loadLatestTurn ->
  // previousBuyerUnitPrice) must apply the exact same reciprocity as the
  // in-memory orchestrator path. Catalog/preset recalibration: originally
  // pinned against orchestrator.test.ts's flagship trace (200 laptops
  // requested, 100 available — a 2:1 shortfall). LAPTOP-14-I5's
  // availableQty dropped 100 -> 10, so this now requests 20 (preserving
  // the SAME 2:1 shortfall ratio against the new stock) rather than 200
  // against a now-wildly-disproportionate 10 — still a genuine,
  // meaningful partial-fulfillment scenario, not an extreme edge case.
  // Values below are freshly verified against the real route handler and
  // real SQLite session/message persistence under the new catalog.
  it("Milestone 4: the merchant's second-round counter reflects buyer reciprocity through the persisted DB-backed history path", async () => {
    const sessionId = await createTestSession(
      { sku: LAPTOP_SKU, quantity: 20, maxUnitPrice: 45000, deliveryDeadlineDays: 10 },
      4,
    );

    const first = await callTurn(sessionId); // round 1: no prior buyer price -> UNKNOWN, neutral
    expect(first.body.buyer.unitPrice).toBe(42750);
    // 46163, not the pre-recalibration 45375: at 20 requested against the
    // new 10-unit stock, the fulfillability leverage component is already
    // fully saturated (clamped) against the merchant, same as any
    // quantity >= 2x availableQty — the merchant holds firmer.
    expect(first.body.merchant.unitPrice).toBe(46163);

    const second = await callTurn(sessionId); // round 2: buyer's ask rose
    expect(second.body.buyer.unitPrice).toBe(44457);
    // Merchant holds at the SAME 46163 both rounds — under this severe a
    // shortfall (fulfillability fully saturated), the merchant's
    // round-aware formula's output lands on the identical clamped value
    // both times; a genuinely observed, real-engine result, not a copy
    // error. Still demonstrates the DB-backed reciprocity path applies
    // consistently across rounds (the property this test exists for),
    // just with a different concrete number under the new catalog.
    expect(second.body.merchant.unitPrice).toBe(46163);
  });

  it("a REJECTED session still returns 409 on a repeated POST (unchanged behavior)", async () => {
    const sessionId = await createTestSession(
      { sku: LAPTOP_SKU, quantity: 10, maxUnitPrice: 45000, deliveryDeadlineDays: 1 },
      4,
    );

    const first = await callTurn(sessionId);
    expect(first.body.status).toBe("REJECTED");

    const second = await callTurn(sessionId);
    expect(second.status).toBe(409);
  });
});

// PACT V2 Milestone 10: move observability, exercised through the real
// route handler and real SQLite session/message persistence — not just
// the in-memory orchestrator.test.ts path. Catalog/preset recalibration:
// LAPTOP-14-I5's availableQty dropped 100 -> 10, so the original 50-unit
// request (comfortably under the old 100-unit stock) now itself EXCEEDS
// the new stock — which blocks QUANTITY_FOR_PRICE entirely
// (decideBuyerQuantityTrade refuses to fire once the merchant is already
// short-supplying the ORIGINAL request; offering even more when already
// stock-constrained is self-defeating, by design). Requesting 5 instead
// (comfortably under the new 10-unit stock, doubling to exactly 10 —
// still never exceeding it) preserves this test's real intent: a
// quantity-for-price trade genuinely firing with stock never the
// limiting factor.
describe("POST /api/negotiations/:id/turn — Milestone 10: move observability", () => {
  it("a quantity-for-price trade round's HTTP response carries move === QUANTITY_FOR_PRICE", async () => {
    // Buyer Quantity-for-Price Redesign: the buyer's own previous-price
    // invariant means the trade can no longer fire on its very first
    // reactive round (round 2) — its own opening ask always sits exactly
    // at target, leaving no meaningful room to improve on immediately.
    // Re-verified live against this real seeded catalog (LAPTOP-14-I5,
    // stock 10): the trade now genuinely fires on round 3, once the
    // buyer has made one real concession in round 2.
    const sessionId = await createTestSession(
      { sku: LAPTOP_SKU, quantity: 5, maxUnitPrice: 45500, deliveryDeadlineDays: 10, urgency: "high" },
      10,
    );

    const first = await callTurn(sessionId); // round 1: ordinary opening exchange
    expect(first.body.buyer.move).toBeUndefined();

    const second = await callTurn(sessionId); // round 2: an ordinary concession — no trade yet
    expect(second.body.buyer.move).toBe("CONCEDE");

    const third = await callTurn(sessionId); // round 3: the quantity-for-price trade fires
    expect(third.body.buyer.move).toBe("QUANTITY_FOR_PRICE");
    expect(third.body.buyer.quantity).toBe(6);

    // 11: every existing field is still present, still correctly typed,
    // and unaffected by the new optional field's presence — a snapshot
    // of the full non-move shape, asserted explicitly rather than
    // trusting TypeScript alone.
    expect(third.body).toMatchObject({
      sessionId,
      turn: 3,
      buyer: {
        sender: "buyer",
        type: "counter_offer",
        sku: LAPTOP_SKU,
        quantity: 6,
        unitPrice: expect.any(Number),
        deliveryDays: expect.any(Number),
        message: expect.any(String),
      },
      merchant: {
        sender: "merchant",
        type: "counter_offer",
        sku: LAPTOP_SKU,
        quantity: expect.any(Number),
        unitPrice: expect.any(Number),
        deliveryDays: expect.any(Number),
        message: expect.any(String),
      },
      status: "COUNTERED",
      round: 3,
      maxRounds: 10,
      agreement: null,
    });
    expect(third.body.leverage.buyer + third.body.leverage.merchant).toBe(100);
  });

  it("a plain accept round's HTTP response carries no move field at all (JSON omits it, not null)", async () => {
    const sessionId = await createTestSession(AGREEING_CONSTRAINTS);

    await callTurn(sessionId); // turn 1: counter_offer
    const closing = await callTurn(sessionId); // turn 2: AGREED (a plain accept)

    expect(closing.body.status).toBe("AGREED");
    expect(closing.body.buyer.move).toBeUndefined();
    expect(closing.body.merchant.move).toBeUndefined();
    // Confirms JSON omission, not a serialized `"move":null`.
    const raw = JSON.stringify(closing.body.buyer);
    expect(raw).not.toContain("move");
  });
});
